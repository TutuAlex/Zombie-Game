﻿/*

#include "objloader.h"


coordinate::coordinate(float a, float b, float c) {
x = a;
y = b;
z = c;
}

face::face(int facen, int f1, int f2, int f3, int t1, int t2, int t3, int m) {
facenum = facen;
faces[0] = f1;
faces[1] = f2;
faces[2] = f3;

texcoord[0] = t1;
texcoord[1] = t2;
texcoord[2] = t3;
mat = m;


four = false;
}

face::face(int facen, int f1, int f2, int f3, int f4, int t1, int t2, int t3, int t4, int m) {
facenum = facen;
faces[0] = f1;
faces[1] = f2;
faces[2] = f3;
faces[3] = f4;

texcoord[0] = t1;
texcoord[1] = t2;
texcoord[2] = t3;
texcoord[3] = t4;
mat = m;



four = true;
}


material::material(const char* na, float al, float n, float ni2, float* d, float* a, float* s, int i, int t)
{
name = na;
alpha = al;
ni = ni2;
ns = n;
dif[0] = d[0];
dif[1] = d[1];
dif[2] = d[2];


amb[0] = a[0];
amb[1] = a[1];
amb[2] = a[2];

spec[0] = s[0];
spec[1] = s[1];
spec[2] = s[2];

illum = i;
texture = t;

}



texcoord::texcoord(float a, float b)

{
u = a;
v = b;

}






int objloader::load(const char* filename)
{

std::ifstream in(filename);
if (!in.is_open())
{
std::cout << "Not Opened" << std::endl;
return -1;
}
char buf[256];
int curmat = 0;
while (!in.eof())
{
in.getline(buf, 256);
coord.push_back(new std::string(buf));
}

for (int i = 0; i < coord.size(); i += 1)
{
if ((*coord[i])[0] == '#')
continue;
else if ((*coord[i])[0] == 'v' && (*coord[i])[1] == ' ')
{
float tmpx, tmpy, tmpz;
sscanf(coord[i]->c_str(), "v %f %f %f", &tmpx, &tmpy, &tmpz);
vertex.push_back(new coordinate(tmpx, tmpy, tmpz));
}
else if ((*coord[i])[0] == 'v' && (*coord[i])[1] == 'n')
{
float tmpx, tmpy, tmpz;
sscanf(coord[i]->c_str(), "vn %f %f %f", &tmpx, &tmpy, &tmpz);
normals.push_back(new coordinate(tmpx, tmpy, tmpz));
}
else if ((*coord[i])[0] == 'f')
{
int a, b, c, d, e;
if (count(coord[i]->begin(), coord[i]->end(), ' ') == 3)
{
if (coord[i]->find("//") != std::string::npos)
{
sscanf(coord[i]->c_str(), "f %d//%d %d//%d %d//%d", &a, &b, &c, &b, &d, &b);
faces.push_back(new face(b, a, c, d, 0, 0, 0, curmat));
}
else if (coord[i]->find("/") != std::string::npos)
{
int t[3];
sscanf(coord[i]->c_str(), "f %d/%d/%d %d/%d/%d %d/%d/%d", &a, &t[0], &b, &c, &t[1], &b, &d, &t[2], &b);
faces.push_back(new face(b, a, c, d, t[0], t[1], t[2], curmat));
}
else
{
sscanf(coord[i]->c_str(), "f %d %d %d", &a, &b, &c);
faces.push_back(new face(-1, a, b, c, 0, 0, 0, curmat));
}





}
else
{

if (coord[i]->find("//")!=std::string::npos)
{
sscanf(coord[i]->c_str(), "f %d//%d %d//%d %d//%d %d//%d", &a, &b, &c, &b, &d, &b, &e, &b);
faces.push_back(new face(b, a, c, d, e, 0, 0, 0, 0,curmat));
}
else if (coord[i]->find("/") != std::string::npos)
{

int t[4];
sscanf(coord[i]->c_str(), "f %d/%d %d/%d %d/%d %d/%d", &a,&t[0], &b, &c,&t[1], &b, &d, &t[2], &b, &e,&t[3], &b);
faces.push_back(new face(b, a, c, d, e, t[0], t[1], t[2], t[3], curmat));

}
else {


sscanf(coord[i]->c_str(), "f %d %d %d %d", &a, &b, &c, &d);
faces.push_back(new face(-1, a, b, c, d, 0, 0, 0, 0, curmat));



}
}
}



else if ((*coord[i])[0] == 'u' && (*coord[i])[1] == 's' && (*coord[i])[2] == 'e')
{
char tmp[200];
sscanf(coord[i]->c_str(), "usemtl %s", tmp);
for (int i = 0; i < materials.size(); i++)
{
if (strcmp(materials[i]->name.c_str(), tmp) == 0)
{
curmat = i;
break;

}

}


}

else if ((*coord[i])[0] == 'm' && (*coord[i])[1] == 't' && (*coord[i])[1] == 'l' && (*coord[i])[3] == 'l')
{
char filen[200];
sscanf(coord[i]->c_str(), "mtllib %s", filen);
std::ifstream mtlin(filen);

if (!mtlin.is_open())
{

std::cout << "cannot open the material file" << std::endl;
clean();
return -1;
}
ismaterial = true;
std::vector<std::string> tmp;
char c[200];

while (!mtlin.eof())
{
mtlin.getline(c, 200);
tmp.push_back(c);

}

char name[200];
char filename[200];

float amb[3], dif[3], spec[3], alpha, ns, ni;

int illum;

unsigned int texture;

bool ismat = false;

strcpy(filename, "\0");

for (int i = 0; i < tmp.size(); i++)
{

if (tmp[i][0] == '#')
continue;



if (tmp[i][0] == 'n' && tmp[i][1] == 'e' && tmp[i][2] == 'w')
{
if (ismat)
{
if (strcmp(filename, "\0") != 0)
{

materials.push_back(new material(name, alpha, ns, ni, dif, amb, spec, illum, texture));
strcpy(filename, "\0");

}
else
{
materials.push_back(new material(name, alpha, ns, ni, dif, amb, spec, illum, -1));

}




}
ismat = false;
sscanf(tmp[i].c_str(), "newmtl %s", name);
}

else if (tmp[i][0] == 'N' && tmp[i][0] == 's')
{

sscanf(tmp[i].c_str(), "Ns %f",&ns);
ismat = true;

}
else if (tmp[i][0] == 'K' && tmp[i][0] == 'a')
{

sscanf(tmp[i].c_str(), "Ka %f %f %f", &amb[0], &amb[1], & amb[2]);
ismat = true;

}
else if (tmp[i][0] == 'K' && tmp[i][0] == 'd')
{

sscanf(tmp[i].c_str(), "Ka %f %f %f", &dif[0], &dif[1], &dif[2]);
ismat = true;

}
else if (tmp[i][0] == 'K' && tmp[i][0] == 's')
{

sscanf(tmp[i].c_str(), "Ks %f %f %f", &spec[0], &spec[1], &spec[2]);
ismat = true;

}
else if (tmp[i][0] == 'N' && tmp[i][0] == 'i')
{

sscanf(tmp[i].c_str(), "Ni %f", &ni);
ismat = true;

}
else if (tmp[i][0] == 'd' && tmp[i][0] == ' ')
{

sscanf(tmp[i].c_str(), "d %f", &alpha);
ismat = true;



}
else if (tmp[i][0] == 'i' && tmp[i][0] == 'l')
{

sscanf(tmp[i].c_str(), "illum %d", &illum);
ismat = true;

}
else if (tmp[i][0] == 'm' && tmp[i][0] == 'a')
{

sscanf(tmp[i].c_str(), "map_Kd %s", filename);
texture = loadTexture(filename);
ismat = true;

}



}
if (ismat)
{
if (strcmp(filename, "\0") != 0)
{

materials.push_back(new material(name, alpha, ns, ni, dif, amb, spec, illum, texture));


}
else
{
materials.push_back(new material(name, alpha, ns, ni, dif, amb, spec, illum, -1));

}




}


}
else if ((*coord[i])[0] == 'v' && (*coord[i])[1] == 't') {

float u, v;
sscanf(coord[i]->c_str(), "vt %f %f", &u, &v);
texturecoordinate.push_back(new texcoord(u, 1 - v));
istexture = true;

}



}


if (materials.size() == 0) //if some reason the material file doesn't contain any material, we don't have material
ismaterial = false;
else    //else we have
ismaterial = true;


// draw
int num;
num = glGenLists(1);
glNewList(num, GL_COMPILE);
int last = -1;

for (int i = 0; i < faces.size(); i += 1)
{


if (last != faces[i]->mat && ismaterial) {
float diffuse[] = { materials[faces[i]->mat]->dif[0], materials[faces[i]->mat]->dif[1] , materials[faces[i]->mat]->dif[2], 1.0 };
float ambient[] = { materials[faces[i]->mat]->amb[0], materials[faces[i]->mat]->amb[1] , materials[faces[i]->mat]->amb[2], 1.0 };
float specular[] = { materials[faces[i]->mat]->spec[0], materials[faces[i]->mat]->spec[1] , materials[faces[i]->mat]->spec[2], 1.0 };

glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
glMaterialfv(GL_FRONT, GL_SPECULAR, specular);

glMaterialf(GL_FRONT, GL_SHININESS, materials[faces[i]->mat]->ns);
last = faces[i]->mat;

if (materials[faces[i]->mat]->texture == -1)
glDisable(GL_TEXTURE_2D);
else
{
glEnable(GL_TEXTURE_2D);
glBindTexture(GL_TEXTURE_2D, materials[faces[i]->mat]->texture);
}



}
if (faces[i]->four)
{
glBegin(GL_QUADS);
glNormal3f(normals[faces[i]->facenum - 1]->x, normals[faces[i]->facenum - 1]->y, normals[faces[i]->facenum - 1]->z);
glVertex3f(vertex[faces[i]->faces[0] - 1]->x, vertex[faces[i]->faces[0] - 1]->y, vertex[faces[i]->faces[0] - 1]->z);
glVertex3f(vertex[faces[i]->faces[1] - 1]->x, vertex[faces[i]->faces[1] - 1]->y, vertex[faces[i]->faces[1] - 1]->z);
glVertex3f(vertex[faces[i]->faces[2] - 1]->x, vertex[faces[i]->faces[2] - 1]->y, vertex[faces[i]->faces[2] - 1]->z);
glVertex3f(vertex[faces[i]->faces[3] - 1]->x, vertex[faces[i]->faces[3] - 1]->y, vertex[faces[i]->faces[3] - 1]->z);
glEnd();
}
else
{
glBegin(GL_TRIANGLES);
glNormal3f(normals[faces[i]->facenum - 1]->x, normals[faces[i]->facenum - 1]->y, normals[faces[i]->facenum - 1]->z);
glVertex3f(vertex[faces[i]->faces[0] - 1]->x, vertex[faces[i]->faces[0] - 1]->y, vertex[faces[i]->faces[0] - 1]->z);
glVertex3f(vertex[faces[i]->faces[1] - 1]->x, vertex[faces[i]->faces[1] - 1]->y, vertex[faces[i]->faces[1] - 1]->z);
glVertex3f(vertex[faces[i]->faces[2] - 1]->x, vertex[faces[i]->faces[2] - 1]->y, vertex[faces[i]->faces[2] - 1]->z);
glEnd();
}
}

glEndList();

clean();
lists.push_back(num);
return num;
}

void objloader::clean()
{

for (int i = 0; i < coord.size(); i ++)
delete coord[i];
for (int i = 0; i < faces.size(); i ++)
delete faces[i];
for (int i = 0; i < normals.size(); i ++)
delete normals[i];
for (int i = 0; i < vertex.size(); i ++)
delete vertex[i];
for (int i = 0; i < materials.size(); i ++)
delete materials[i];
for (int i = 0; i < texturecoordinate.size(); i ++)
delete texturecoordinate[i];


coord.clear();
faces.clear();
normals.clear();
vertex.clear();
materials.clear();
texturecoordinate.clear();
}


objloader::~objloader()
{

for (std::vector<unsigned int>::const_iterator it = texture.begin(); it != texture.end(); it++)
{
glDeleteTextures(1, &(*it));
}
for (std::vector<unsigned int>::const_iterator it = lists.begin(); it != lists.end(); it++)
{
glDeleteLists(*it, 1);
}

}

unsigned int objloader::loadTexture(const char* filename)
{
//SDL has functions to load an image NOT OpenGL
unsigned int num;
glGenTextures(1, &num);
SDL_Surface* img = SDL_LoadBMP(filename);


glBindTexture(GL_TEXTURE_2D, num);

glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img->w, img->h, 0, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, img->pixels);

glTexEnvi(GL_TEXTURE_2D, GL_TEXTURE_ENV_MODE, GL_MODULATE);
SDL_FreeSurface(img);
texture.push_back(num);

return num;

}

objloader::objloader()
{
ismaterial = false;
isnormals = false;
istexture = false;


}

*/


/*




float angle = 0.0;

//this is for the triangle
//const int triangle = 1;
























//texture
unsigned int  tex;

objloader obj;

//cube .obj
int cube;

void init()
{
glClearColor(0.0, 0.0, 0.0, 1.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluPerspective(45, 640.0 / 480.0, 1.0, 500.0);
glMatrixMode(GL_MODELVIEW);
//glShadeModel(GL_SMOOTH);

//glNewList(triangle, GL_COMPILE);


//	glScalef(1.0, 0.5, 1.0);
//glBegin(GL_TRIANGLES);
//glColor3f(1.0, 0.0, 0.0);
//	glVertex3f(0.0, 2.0, 0.0);
//	glColor3f(0.0, 1.0, 0.0);
//	glVertex3f(-2.0, -2.0, 0.0);
//	glColor3f(0.0, 0.0, 1.0);
//	glVertex3f(2.0, -2.0, 0.0);
//   glEnd();

//glEndList();

glEnable(GL_DEPTH_TEST);

cube = obj.load("suzanne.obj");




//glEnable(GL_TEXTURE_2D);

//tex = loadTexture("bricks3.bmp");

glEnable(GL_LIGHTING);
glEnable(GL_LIGHT0);

glEnable(GL_BLEND);
glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

//glEnable(GL_FOG);

//glFogi(GL_FOG_MODE, GL_EXP);

//THESE FOR LINEAR FOG (instead of expodential (EXP))

//glFogf(GL_FOG_START, 1.0);
//glFogf(GL_FOG_END, 5.0);

//glFogf(GL_FOG_DENSITY, 0.6);

float color[] = { 0.5, 0.5, 0.5, 1.0 };

glFogfv(GL_FOG_COLOR, color);

//glEnable(GL_COLOR_MATERIAL);


float col[] = { 1.0,1.0,1.0,1.0 };  //light color is white
glLightfv(GL_LIGHT0, GL_DIFFUSE, col);

//float dif[] = {1.0, 1.0, 1.0, 1.0};
//glLightfv(GL_LIGHT0, GL_DIFFUSE, dif);

//float amb[] = { 0.2, 0.2, 0.2, 0.2 };
//	glLightfv(GL_LIGHT0, GL_AMBIENT, amb);


}



void display()
{

glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

glLoadIdentity();

float pos[] = { -2.0, 2.0, -3.0, 1.0 };
glLightfv(GL_LIGHT0, GL_POSITION, pos);
//glDisable(GL_LIGHTING);


//glPushMatrix();

//glTranslatef(-2.0, 0.0, -10.0);
//glRotatef(angle, 1.0, 1.0, 1.0);


// glBindTexture(GL_TEXTURE_2D, tex);

//makes plane
//glBegin(GL_QUADS);

//	glColor4f(0.0, 0.0, 1.0, 1.0);
//	glTexCoord2f(0.0, 1.0);
//glVertex3f(-2.0, 2.0, -10.0);
//  glTexCoord2f(0.0, 0.0);
//glVertex3f(-2.0, -2.0, -10.0);
//	glTexCoord2f(1.0, 0.0);
//glVertex3f(2.0, -2.0, -10.0);
//   glTexCoord2f(1.0, 1.0);
//glVertex3f(2.0, 2.0, -10.0);


//	glColor4f(1.0, 0.0, 0.0, 0.5);
//glVertex3f(-1.0, 3.0, -9.0);
//	glVertex3f(-1.0, -3.0, -9.0);
//	glVertex3f(3.0, -3.0, -9.0);
//	glVertex3f(3.0, 3.0, -9.0);




//glEnd();
//this draws the cube above
//drawCube(1.0);


//this scales
//glScalef(1.0, 0.5, 1.0);


//this calls the triangle list above
//glCallList(triangle);

glCallList(cube);
//glPopMatrix();

//glTranslatef(2.0, 0.0, -8.0);
//glRotatef(-angle ,1, 1, 1);
//glCallList(cube);

}




int main(int argc, char **argv) {

//if (SDL_Init(SDL_INIT_EVERYTHING) < 0) {

//	std::cout <<"SDL could not initialize.. SDL error: " << SDL_GetError() << std::endl;
//}

SDL_Init(SDL_INIT_EVERYTHING);
SDL_Surface* screen;
screen = SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE | SDL_OPENGL);
bool running = true;



const int FPS = 30;
Uint32  start;
SDL_Event event;

init();

while (running)
{
start = SDL_GetTicks();

while (SDL_PollEvent(&event))
{
switch (event.type)
{

case SDL_QUIT:
running = false;
break;
}
}

//logic and render

display();
SDL_GL_SwapBuffers();
angle += 0.5;

if (angle > 360) {
angle -= 360;

}

//SDL_Flip(screen);
if (1000 / FPS > SDL_GetTicks() - start)
{
SDL_Delay(1000 / FPS - (SDL_GetTicks() - start));
}

}


SDL_Quit();













vector3d vec1;
vector3d vec2(1, 2, 3);
vector3d vec3(6, 5, 4);
std::cout << vec1 << vec2;
std::cout << vec2.length() << std::endl;

vec2.normalize();
std::cout << vec2;
vector3d vec4 = vec2 + vec3;

std::cout << vec4;

vec4 = vec2;
std::cout << vec4;
//







//return EXIT_SUCCESS;
//system("pause");
return 0;
}


*/


/*


#ifndef OBJLOADER
#define OBJLOADER



struct coordinate {
float x, y, z;
coordinate(float a, float b, float c);
};

struct face {
int facenum;
bool four;
int faces[4];
int texcoord[4];
int mat;

face(int facen, int f1, int f2, int f3, int t1, int t2, int t3, int m);
face(int facen, int f1, int f2, int f3, int f4, int t1, int t2, int t3,int t4, int m);
};


struct material {

std::string name;
float alpha, ns, ni;
float dif[3], amb[3], spec[3];
int illum;
int texture;

material(const char* na, float al, float n, float ni2, float* d, float* a, float* s, int i, int t);

};

struct texcoord {
float u, v;
texcoord(float a, float b);


};





class objloader {

std::vector<std::string*> coord;
std::vector<coordinate*> vertex;
std::vector<face*> faces;
std::vector<coordinate*> normals;
std::vector<unsigned int> texture;
std::vector<unsigned int> lists;
std::vector<material*> materials;
std::vector<texcoord*> texturecoordinate;

bool ismaterial, isnormals, istexture;
unsigned int loadTexture(const char* filename);
void clean();

public:

objloader();

~objloader();


int load(const char* filename);

};





*/





/*

#include "functions.h"

float camX = 0.0, camY, camZ = 5.0;

float camYaw = 0.0;

float camPitch = 0.0;



#ifndef M_PI
#define M_PI 3.1415926535 

#endif


void lockCamera()

{
	if (camPitch > 90)
		camPitch = 90;
	if (camPitch < -90);
	camPitch = -90;
	if (camYaw < 0.0)
		camYaw += 360;
	if (camYaw > 360)
		camYaw -= 360;
}



void moveCamera(float dist, float dir)
{
	float rad = (camYaw + dir)*M_PI / 180.0;
	camX -= sin(rad)*dist;
	camZ -= cos(rad)*dist;
}




void moveCameraUp(float dist, float dir) {

	float rad = (camPitch + dir)*M_PI / 180.0;
	camY -= sin(rad)*dist;


}

void Control(float movevel, float mousevel, bool mi) {

	if (mi)
	{
		int MidX = 320;
		int MidY = 240;
		SDL_ShowCursor(SDL_DISABLE);

		int tmpx, tmpy;
		SDL_GetMouseState(&tmpx, &tmpy);

		camYaw += mousevel*(MidX - tmpx);
		camPitch += mousevel*(MidY - tmpy);
		lockCamera();
		SDL_WarpMouse(MidX, MidY);
		Uint8* state = SDL_GetKeyState(NULL);
		if (state[SDLK_w])
		{

			if (camPitch != 90 && camPitch != -90)
				moveCamera(movevel, 0.0);
			moveCameraUp(movevel, 0.0);

		}
		else if (state[SDLK_s]) {

			if (camPitch != 90 && camPitch != -90)
				moveCamera(movevel, 0.0);
			moveCameraUp(movevel, 0.0);
		}
		if (state[SDLK_a])
		{
			moveCamera(movevel, 90.0);

		}
		else if (state[SDLK_d]) {
			moveCamera(movevel, 270);
		}

	

	}

	glRotatef(-camPitch, 1.0, 0.0, 0.0);
	glRotatef(-camYaw, 0.0, 1.0, 0.0);

}



void UpdateCamera()
{

	glTranslatef(-camX, -camY, -camZ);


}

*/













/* NEW MAIN







float angle = 0.0;

int cube;
objloader obj;//create an instance of the objloader
bool mousein = false;

coordinate spherecenter(0.0, 0.0, 0.0);
coordinate raystart(0.0, 0.0, -5.0);













void init()
{
glClearColor(0.5, 0.5, 0.5, 1.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluPerspective(45, 640.0 / 480.0, 1.0, 500.0);
glMatrixMode(GL_MODELVIEW);
glEnable(GL_DEPTH_TEST);
cube = obj.load("therealone.obj");      //load it
glEnable(GL_LIGHTING);
glEnable(GL_LIGHT0);
float col[] = { 1.0,1.0,1.0,1.0 };
glLightfv(GL_LIGHT0, GL_DIFFUSE, col);
initSkybox();
}

void display()
{
glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glLoadIdentity();
Control(0.2, 0.2, mousein);
drawSkybox(50.0);
UpdateCamera();

float pos[] = { -2.0,2.0,-3.0,1.0 };
glLightfv(GL_LIGHT0, GL_POSITION, pos);
//glTranslatef(-2.0, 00.0, -10.0);
//glRotatef(angle, 1.0, 1.0, 1.0);

if (raysphere(spherecenter.x, spherecenter.y, spherecenter.z, 0.0, 0.0, 1.0, raystart.x, raystart.y, raystart.z, 1.0))

glColor3f(1.0, 0.0, 0.0);
else
glColor3f(1.0, 1.0, 1.0);


glBegin(GL_LINES);

glVertex3f(raystart.x, raystart.y, raystart.z);
glVertex3f(raystart.x + 100 * 0, raystart.y + 100 * 0, raystart.z + 100 * 0);

glEnd();
glCallList(cube);       //and display it

glColor3f(1.0, 1.0, 1.0);
}



void test1() {

SDL_Init(SDL_INIT_EVERYTHING);
SDL_Surface* screen = SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE | SDL_OPENGL);
bool running = true;
Uint32 start;
SDL_Event event;
init();

bool b[4] = { 0,0,0,0 };

while (running)
{
start = SDL_GetTicks();
while (SDL_PollEvent(&event))
{
switch (event.type)
{
case SDL_QUIT:
running = false;
break;
case SDL_MOUSEBUTTONDOWN:
mousein = true;
SDL_ShowCursor(SDL_DISABLE);
break;
case SDL_KEYDOWN:
if (event.key.keysym.sym == SDLK_p)
{
mousein = false;
SDL_ShowCursor(SDL_ENABLE);
break;
}if (event.key.keysym.sym == SDLK_ESCAPE)
{
running = false;
break;
}


switch (event.key.keysym.sym)
{
case SDLK_UP:
b[0] = 1;
break;
case SDLK_LEFT:
b[1] = 1;
break;
case SDLK_DOWN:
b[2] = 1;
break;
case SDLK_RIGHT:
b[3] = 1;
break;


}
break;


case SDL_KEYUP:
switch (event.key.keysym.sym)
{
case SDLK_UP:
b[0] = 0;
break;
case SDLK_LEFT:
b[1] = 0;
break;
case SDLK_DOWN:
b[2] = 0;
break;
case SDLK_RIGHT:
b[3] = 0;
break;


}
break;




}

}

if (b[0])
raystart.y += 0.3;
if (b[1])
raystart.x-= 0.3;
if (b[2])
raystart.y -= 0.3;
if (b[3])
raystart.x += 0.3;


display();
SDL_GL_SwapBuffers();
angle += 0.5;
if (angle > 360)
angle -= 360;
if (1000 / 30 > (SDL_GetTicks() - start))
SDL_Delay(1000 / 30 - (SDL_GetTicks() - start));
}
SDL_Quit();
killSkybox();





}





void test2() {

SDL_Init(SDL_INIT_EVERYTHING);
SDL_Surface* screen = SDL_SetVideoMode(840, 680, 32, SDL_SWSURFACE | SDL_OPENGL);
bool running = true;
Uint32 start;
SDL_Event event;
init();

while (running)
{
start = SDL_GetTicks();
while (SDL_PollEvent(&event))
{
switch (event.type)
{
case SDL_QUIT:
running = false;
break;
case SDL_MOUSEBUTTONDOWN:
mousein = true;
SDL_ShowCursor(SDL_DISABLE);
break;
case SDL_KEYDOWN:
if (event.key.keysym.sym == SDLK_p)
{
mousein = false;
SDL_ShowCursor(SDL_ENABLE);
break;
}if (event.key.keysym.sym == SDLK_ESCAPE)
{
running = false;
break;
}
}

}
display();
SDL_GL_SwapBuffers();
angle += 0.5;
if (angle > 360)
angle -= 360;
if (1000 / 30 > (SDL_GetTicks() - start))
SDL_Delay(1000 / 30 - (SDL_GetTicks() - start));
}
SDL_Quit();
killSkybox();





}










int main(int argc, char** argv)
{

test1();
//	test2();
return 0;

}








*/