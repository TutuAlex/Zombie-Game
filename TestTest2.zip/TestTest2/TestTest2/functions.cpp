﻿#include "functions.h"

float camX = 0.0, camY = 0.0, camZ = 5.0; //coords for the camera (position in the world)
float camYaw = 0.0; //the float that holds the value of the cameras rotation left and right
float camPitch = 0.0;  //the float that holds the value of the cameras movement up and down

enum { SKY_LEFT = 0, SKY_BACK, SKY_RIGHT, SKY_FRONT, SKY_TOP, SKY_BOTTOM }; //sides of the skybox;
unsigned int skybox[6];

// defines π
#ifndef M_PI
#define M_PI 3.1415926535
#endif


void initskybox()
{
	skybox[SKY_LEFT] = loadTexture("left.bmp");
	skybox[SKY_BACK] = loadTexture("back.bmp");
	skybox[SKY_RIGHT] = loadTexture("right.bmp");
	skybox[SKY_FRONT] = loadTexture("front.bmp");
	skybox[SKY_TOP] = loadTexture("top.bmp");
	skybox[SKY_BOTTOM] = loadTexture("bottom.bmp");
}

void killskybox()
{
	glDeleteTextures(6, &skybox[0]);
}

void lockCamera()
{
	if (camPitch>90)
		camPitch = 90;
	if (camPitch<-90)
		camPitch = -90;
	if (camYaw<0.0)
		camYaw += 360.0;
	if (camYaw>360.0)
		camYaw -= 360;
}

void moveCamera(float dist, float dir)
{
	float rad = (camYaw + dir)*M_PI / 180.0;
	camX -= sin(rad)*dist;
	camZ -= cos(rad)*dist;

	
}

void moveCameraUp(float dist, float dir)
{
	float rad = (camPitch + dir)*M_PI / 180.0;
	camY += sin(rad)*dist;
}

void Control(float movevel, float mousevel, bool mi)
{
	if (mi)
	{
		int MidX = 320;
		int MidY = 240;
		SDL_ShowCursor(SDL_DISABLE);
		int tmpx, tmpy;
		SDL_GetMouseState(&tmpx, &tmpy);
		camYaw += mousevel*(MidX - tmpx);
		camPitch += mousevel*(MidY - tmpy);
		lockCamera();
		SDL_WarpMouse(MidX, MidY);
		Uint8* state = SDL_GetKeyState(NULL);
		if (state[SDLK_w])
		{
			if (camPitch != 90 && camPitch != -90)
				moveCamera(movevel, 0.0);
			moveCameraUp(movevel, 0.0);
		}
		else if (state[SDLK_s])
		{
			if (camPitch != 90 && camPitch != -90)
				moveCamera(movevel, 180.0);
			moveCameraUp(movevel, 180.0);
		}
		if (state[SDLK_a])
			moveCamera(movevel, 90.0);
		else if (state[SDLK_d])
			moveCamera(movevel, 270);
	}
	glRotatef(-camPitch, 1.0, 0.0, 0.0);
	glRotatef(-camYaw, 0.0, 1.0, 0.0);
}

void UpdateCamera()
{
	glTranslatef(-camX, -camY, -camZ); //using - values cause were making the illusion of moving, but in reality were moving the world in relation to us.
}

void drawCube(float size)
{
	float difamb[] = { 1.0,0.5,0.3,1.0 };
	glBegin(GL_QUADS);
	//front face
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, difamb);
	glNormal3f(0.0, 0.0, 1.0);
	glVertex3f(size / 2, size / 2, size / 2);
	glVertex3f(-size / 2, size / 2, size / 2);
	glVertex3f(-size / 2, -size / 2, size / 2);
	glVertex3f(size / 2, -size / 2, size / 2);

	//left face
	glNormal3f(-1.0, 0.0, 0.0);
	glVertex3f(-size / 2, size / 2, size / 2);
	glVertex3f(-size / 2, size / 2, -size / 2);
	glVertex3f(-size / 2, -size / 2, -size / 2);
	glVertex3f(-size / 2, -size / 2, size / 2);

	//back face
	glNormal3f(0.0, 0.0, -1.0);
	glVertex3f(size / 2, size / 2, -size / 2);
	glVertex3f(-size / 2, size / 2, -size / 2);
	glVertex3f(-size / 2, -size / 2, -size / 2);
	glVertex3f(size / 2, -size / 2, -size / 2);

	//right face
	glNormal3f(1.0, 0.0, 0.0);
	glVertex3f(size / 2, size / 2, -size / 2);
	glVertex3f(size / 2, size / 2, size / 2);
	glVertex3f(size / 2, -size / 2, size / 2);
	glVertex3f(size / 2, -size / 2, -size / 2);

	//top face
	glNormal3f(0.0, 1.0, 0.0);
	glVertex3f(size / 2, size / 2, size / 2);
	glVertex3f(-size / 2, size / 2, size / 2);
	glVertex3f(-size / 2, size / 2, -size / 2);
	glVertex3f(size / 2, size / 2, -size / 2);

	//bottom face
	glNormal3f(0.0, -1.0, 0.0);
	glVertex3f(size / 2, -size / 2, size / 2);
	glVertex3f(-size / 2, -size / 2, size / 2);
	glVertex3f(-size / 2, -size / 2, -size / 2);
	glVertex3f(size / 2, -size / 2, -size / 2);
	glEnd();
}

void drawSkybox(float size)
{
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, skybox[SKY_BACK]);
	glBegin(GL_QUADS);
	//back face
	glTexCoord2f(0, 0);
	glVertex3f(size / 2, size / 2, size / 2);
	glTexCoord2f(1, 0);
	glVertex3f(-size / 2, size / 2, size / 2);
	glTexCoord2f(1, 1);
	glVertex3f(-size / 2, -size / 2, size / 2);
	glTexCoord2f(0, 1);
	glVertex3f(size / 2, -size / 2, size / 2);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, skybox[SKY_LEFT]);
	glBegin(GL_QUADS);
	//left face
	glTexCoord2f(0, 0);
	glVertex3f(-size / 2, size / 2, size / 2);
	glTexCoord2f(1, 0);
	glVertex3f(-size / 2, size / 2, -size / 2);
	glTexCoord2f(1, 1);
	glVertex3f(-size / 2, -size / 2, -size / 2);
	glTexCoord2f(0, 1);
	glVertex3f(-size / 2, -size / 2, size / 2);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, skybox[SKY_FRONT]);
	glBegin(GL_QUADS);
	//front face
	glTexCoord2f(1, 0);
	glVertex3f(size / 2, size / 2, -size / 2);
	glTexCoord2f(0, 0);
	glVertex3f(-size / 2, size / 2, -size / 2);
	glTexCoord2f(0, 1);
	glVertex3f(-size / 2, -size / 2, -size / 2);
	glTexCoord2f(1, 1);
	glVertex3f(size / 2, -size / 2, -size / 2);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, skybox[SKY_RIGHT]);
	glBegin(GL_QUADS);
	//right face
	glTexCoord2f(0, 0);
	glVertex3f(size / 2, size / 2, -size / 2);
	glTexCoord2f(1, 0);
	glVertex3f(size / 2, size / 2, size / 2);
	glTexCoord2f(1, 1);
	glVertex3f(size / 2, -size / 2, size / 2);
	glTexCoord2f(0, 1);
	glVertex3f(size / 2, -size / 2, -size / 2);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, skybox[SKY_TOP]);
	glBegin(GL_QUADS);                      //top face
	glTexCoord2f(1, 0);
	glVertex3f(size / 2, size / 2, size / 2);
	glTexCoord2f(0, 0);
	glVertex3f(-size / 2, size / 2, size / 2);
	glTexCoord2f(0, 1);
	glVertex3f(-size / 2, size / 2, -size / 2);
	glTexCoord2f(1, 1);
	glVertex3f(size / 2, size / 2, -size / 2);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, skybox[SKY_BOTTOM]);
	glBegin(GL_QUADS);
	//bottom face
	glTexCoord2f(1, 1);
	glVertex3f(size / 2, -size / 2, size / 2);
	glTexCoord2f(0, 1);
	glVertex3f(-size / 2, -size / 2, size / 2);
	glTexCoord2f(0, 0);
	glVertex3f(-size / 2, -size / 2, -size / 2);
	glTexCoord2f(1, 0);
	glVertex3f(size / 2, -size / 2, -size / 2);
	glEnd();
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_2D);
}

bool raysphere(float xc, float yc, float zc, float xd, float yd, float zd, float xs, float ys, float zs, float r, float* dist, vector3d* point)
{
	float b = 2 * (xd*(xs - xc) + yd*(ys - yc) + zd*(zs - zc));
	float c = xs*xs - 2 * xs*xc + xc*xc + ys*ys - 2 * ys*yc + yc*yc + zs*zs - 2 * zs*zc + zc*zc - r*r;
	float disc = (b*b - 4 * c);
	if (disc<0)
		return false;
	if (dist != NULL)
	{
		//-b+disc/2
		(*dist) = (-b + disc) / 2;
		if (point != NULL)
		{
			//xs+t*xd
			point->x = xs + (*dist)*xd;
			point->y = ys + (*dist)*yd;
			point->z = zs + (*dist)*zd;
		}
	}
	return true;
	
}

bool rayplane(float nx, float ny, float nz, float xs, float ys, float zs, float xd, float yd, float zd, vector3d p1, vector3d p2, vector3d p3, vector3d p4, float* dist, vector3d* point)
{
	float a = xd*nx + yd*ny + zd*nz;
	if (a == 0)
		return false;
	float t = ((p1.x*nx + p1.y*ny + p1.z*nz - nx*xs - ny*ys - nz*zs) / a);
	if (t<0)
		return false;
	float x = xs + t*xd;
	float y = ys + t*yd;
	float z = zs + t*zd;
	vector3d cp(x, y, z);
	if (abs(trianglearea(p1, p3, p4) - trianglearea(p1, p4, cp) - trianglearea(p1, p3, cp) - trianglearea(p3, p4, cp))<0.000001 || abs(trianglearea(p1, p2, p3) - trianglearea(p1, p2, cp) - trianglearea(p2, p3, cp) - trianglearea(p1, p3, cp))<0.000001)
	{
		if (dist != NULL)
		{
			(*dist) = t;
			if (point != NULL)
			{
				point->x = x;
				point->y = y;
				point->z = z;
			}
		}
		return true;
	}
	return false;
}


float trianglearea(vector3d p1, vector3d p2, vector3d p3)
{
	//area of the triangle with the heron fomula
	float a = sqrt((p2.x - p1.x)*(p2.x - p1.x) + (p2.y - p1.y)*(p2.y - p1.y) + (p2.z - p1.z)*(p2.z - p1.z));
	float b = sqrt((p3.x - p2.x)*(p3.x - p2.x) + (p3.y - p2.y)*(p3.y - p2.y) + (p3.z - p2.z)*(p3.z - p2.z));
	float c = sqrt((p1.x - p3.x)*(p1.x - p3.x) + (p1.y - p3.y)*(p1.y - p3.y) + (p1.z - p3.z)*(p1.z - p3.z));
	float s = (a + b + c) / 2.;
	return (sqrt(s*((s - a)*(s - b)*(s - c))));

}


unsigned int loadTexture(const char* filename)
{
	unsigned int num;
	glGenTextures(1, &num);
	SDL_Surface* img = SDL_LoadBMP(filename);
	glBindTexture(GL_TEXTURE_2D, num);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	//      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
	//      glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img->w, img->h, 0, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, img->pixels);
	SDL_FreeSurface(img);
	return num;
}

bool spheresphere(vector3d& c1, float r1, vector3d c2, float r2)
{
	float dist = pointdistance(c1, c2);
	if (dist <= (r1 + r2)*(r1 + r2))
	{
		float a = sqrt(dist) - (r1 + r2);
		vector3d vec(c2.x - c1.x, c2.y - c1.y, c2.z - c1.z);  //c2-c1
		float len = sqrt((vec.x*vec.x + vec.y*vec.y + vec.z*vec.z));
		vec.x /= len;
		vec.y /= len;
		vec.z /= len;
		c1.x = c1.x + vec.x*a;
		c1.y = c1.y + vec.y*a;
		c1.z = c1.z + vec.z*a;
		return 1;
	}
	return 0;
}

float pointdistance(vector3d c1, vector3d c2)
{
	vector3d vec(c2.x - c1.x, c2.y - c1.y, c2.z - c1.z);
	return (vec.x*vec.x + vec.y*vec.y + vec.z*vec.z);
}

void moveTo(vector3d c)
{
	camX = c.x;
	camY = c.y;
	camZ = c.z;
}
vector3d camPos()
{
	return (vector3d(camX, camY, camZ));
}

bool sphereplane(vector3d& sp, vector3d vn, vector3d p1, vector3d p2, vector3d p3, vector3d p4, float r)
{
	//float nx,float ny,float nz,float xs,float ys,float zs,float xd,float yd,float zd,vector3d p1,vector3d p2,vector3d p3,vector3d p4,float* dist,vector3d* point)
	float dist1 = 0, dist2 = 0;
	if (rayplane(-vn.x, -vn.y, -vn.z, sp.x, sp.y, sp.z, vn.x, vn.y, vn.z, p1, p2, p3, p4, &dist1) || rayplane(vn.x, vn.y, vn.z, sp.x, sp.y, sp.z, -vn.x, -vn.y, -vn.z, p1, p2, p3, p4, &dist2))
	{
		if (dist1>r || dist2>r)
			return false;
		if (dist1>0)
		{
			sp.x = sp.x - vn.x*(r - dist1);
			sp.y = sp.y - vn.y*(r - dist1);
			sp.z = sp.z - vn.z*(r - dist1);
		}
		else {
			sp.x = sp.x + vn.x*(r - dist2);
			sp.y = sp.y + vn.y*(r - dist2);
			sp.z = sp.z + vn.z*(r - dist2);
		}
		return 1;
	}
	return 0;
}
