#include<SDL.h>
#include <iostream>
#include<cmath>


#include<gl\glew.h>
#include<GL\GL.h>
#include<GL\GLU.h>

#include <cstdlib>
#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include <cstdio>

#include "objloader.h"

#ifndef FUNCTION_H
#define FUNCTION_H



void drawCube(float size);
void drawSkybox(float size);
void initskybox();
void killskybox();


unsigned int loadTexture(const char* filename);




void lockCamera(); //locks camera at +90 or -90 degrees (so that if we continue looking up or down, it doesnt flip to the other side)

void moveCamera(float, float); // moves camera

void moveCameraUp(float, float); //moves camera up or down

void Control(float, float, bool); //function that assigns player imput to camera movement and also his own.

void UpdateCamera();

bool raysphere(float xc, float yc, float zc, float xd, float yd, float zd, float xs, float ys, float zs, float r, float* dist = NULL, vector3d* point = NULL);
bool rayplane(float nx, float ny, float nz, float xs, float ys, float zs, float xd, float yd, float zd, vector3d p1, vector3d p2, vector3d p3, vector3d p4, float* dist = NULL, vector3d* point = NULL);
float trianglearea(vector3d p1, vector3d p2, vector3d p3);

bool spheresphere(vector3d& c1, float r1, vector3d c2, float r2);
float pointdistance(vector3d c1, vector3d c2);
void moveTo(vector3d c);
vector3d camPos();
bool sphereplane(vector3d& sp, vector3d vn, vector3d p1, vector3d p2, vector3d p3, vector3d p4, float r);



#endif